
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { 
  Menu, X, Phone, Mail, MapPin, Clock, 
  ChevronRight, ChevronUp, HardHat, Pickaxe, Trash2, 
  Layout, Layers, Tractor, Hammer, Construction, 
  Wind, Sun, Trophy, ShieldCheck, Leaf, Lightbulb, 
  Handshake, Users, ArrowRight, MessageSquare,
  HelpCircle
} from 'lucide-react';

// --- SEO and Utility Components ---

const PageSEO = ({ title, description, path }: { title: string, description: string, path: string }) => {
  useEffect(() => {
    // Título dinámico
    document.title = `${title} | Tritón S.A.C.`;
    
    // Meta descripción dinámica
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc) {
      metaDesc.setAttribute('content', description);
    }
    
    // Enlace canónico dinámico
    const canonical = document.getElementById('canonical-link');
    if (canonical) {
      canonical.setAttribute('href', `https://triton.com.pe/#${path}`);
    }

    // OG Url dinámica
    const ogUrl = document.querySelector('meta[property="og:url"]');
    if (ogUrl) {
      ogUrl.setAttribute('content', `https://triton.com.pe/#${path}`);
    }
  }, [title, description, path]);
  return null;
};

const StructuredData = ({ path }: { path: string }) => {
  const isHome = path === '/' || path === '';
  
  const businessSchema = {
    "@context": "https://schema.org",
    "@type": "LocalBusiness",
    "name": "Corporación Internacional Tritón S.A.C.",
    "alternateName": "Tritón S.A.C.",
    "image": "https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=1200&q=80",
    "@id": "https://triton.com.pe",
    "url": "https://triton.com.pe",
    "telephone": "+5112555650",
    "priceRange": "$$$",
    "address": {
      "@type": "PostalAddress",
      "streetAddress": "Av. Alameda Los Cedros Nº 185 - Of. 401",
      "addressLocality": "Chorrillos",
      "addressRegion": "Lima",
      "postalCode": "15067",
      "addressCountry": "PE"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": -12.192083,
      "longitude": -77.012542
    },
    "openingHoursSpecification": {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "08:00",
      "closes": "18:00"
    }
  };

  const breadcrumbSchema = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    "itemListElement": [
      {
        "@type": "ListItem",
        "position": 1,
        "name": "Inicio",
        "item": "https://triton.com.pe/#/"
      },
      !isHome ? {
        "@type": "ListItem",
        "position": 2,
        "name": path.replace('/', '').charAt(0).toUpperCase() + path.slice(2),
        "item": `https://triton.com.pe/#${path}`
      } : null
    ].filter(Boolean)
  };

  return (
    <>
      <script type="application/ld+json">{JSON.stringify(businessSchema)}</script>
      <script type="application/ld+json">{JSON.stringify(breadcrumbSchema)}</script>
    </>
  );
};

const FAQSchema = () => {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "¿Qué servicios ofrece Tritón S.A.C.?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Ofrecemos servicios especializados en movimiento de tierras, demolición controlada, gestión de desmonte y preparación de terrenos para infraestructura."
        }
      },
      {
        "@type": "Question",
        "name": "¿Realizan proyectos fuera de Lima?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "Sí, Tritón S.A.C. tiene capacidad operativa para ejecutar proyectos de ingeniería y construcción en todo el territorio nacional y a nivel internacional."
        }
      }
    ]
  };
  return <script type="application/ld+json">{JSON.stringify(faqSchema)}</script>;
};

const BackToTop = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 400) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };
    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  return (
    <button
      onClick={scrollToTop}
      className={`fixed bottom-8 right-8 z-[60] bg-[#e67e22] text-white p-4 rounded-full shadow-2xl transition-all duration-300 hover:bg-[#d35400] hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#e67e22] ${
        isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'
      }`}
      aria-label="Volver arriba"
    >
      <ChevronUp size={24} strokeWidth={3} />
    </button>
  );
};

const Header = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  const navLinks = [
    { name: 'Inicio', path: '/' },
    { name: 'Servicios', path: '/servicios' },
    { name: 'Especialidades', path: '/especialidades' },
    { name: 'Nosotros', path: '/nosotros' },
    { name: 'Contacto', path: '/contacto' },
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-[#0a192f]/95 backdrop-blur-md shadow-lg py-3' : 'bg-[#0a192f] py-5'}`}>
      <div className="container mx-auto px-4 md:px-8">
        <div className="flex justify-between items-center">
          <Link to="/" className="flex items-center gap-3 group" aria-label="Tritón S.A.C. - Inicio">
            <div className="w-12 h-12 md:w-14 md:h-14 bg-gradient-to-br from-[#e67e22] to-[#d35400] rounded-full flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
              <Construction className="text-white w-7 h-7" aria-hidden="true" />
            </div>
            <div className="flex flex-col">
              <span className="text-white text-xl md:text-2xl font-black leading-tight tracking-tight uppercase">Tritón S.A.C</span>
              <span className="text-[#e67e22] text-[10px] md:text-xs font-bold tracking-[2px] uppercase">Corporación Internacional</span>
            </div>
          </Link>

          <nav className="hidden lg:flex items-center gap-10" aria-label="Navegación principal">
            <ul className="flex gap-8">
              {navLinks.map((link) => (
                <li key={link.name}>
                  <Link 
                    to={link.path} 
                    aria-current={location.pathname === link.path ? 'page' : undefined}
                    className={`text-sm font-semibold uppercase tracking-wider transition-colors hover:text-[#e67e22] relative pb-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:h-[2px] after:bg-[#e67e22] after:transition-all after:duration-300 ${location.pathname === link.path ? 'text-[#e67e22] after:w-full' : 'text-white after:w-0 hover:after:w-full'}`}
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
            <a href="https://wa.me/51989123055" target="_blank" rel="noopener noreferrer" className="bg-gradient-to-r from-[#e67e22] to-[#d35400] text-white px-6 py-2.5 rounded-full font-bold text-sm uppercase tracking-wider flex items-center gap-2 hover:translate-y-[-2px] hover:shadow-xl transition-all shadow-md">
              <MessageSquare className="w-4 h-4" /> Cotizar Online
            </a>
          </nav>

          <button className="lg:hidden text-white p-2 rounded-lg hover:bg-white/10 transition-colors" onClick={() => setIsOpen(!isOpen)} aria-label={isOpen ? "Cerrar menú de navegación" : "Abrir menú de navegación"}>
            {isOpen ? <X size={32} /> : <Menu size={32} />}
          </button>
        </div>
      </div>

      <div className={`lg:hidden fixed inset-0 top-[76px] bg-[#0a192f] z-40 flex flex-col items-center justify-center gap-8 transition-transform duration-500 ease-in-out ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}>
        <nav aria-label="Menú móvil">
          <ul className="flex flex-col items-center gap-6">
            {navLinks.map((link) => (
              <li key={link.name}>
                <Link 
                  to={link.path} 
                  onClick={() => setIsOpen(false)}
                  className={`text-2xl font-bold uppercase tracking-widest transition-colors ${location.pathname === link.path ? 'text-[#e67e22]' : 'text-white hover:text-[#e67e22]'}`}
                >
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </header>
  );
};

const Footer = () => {
  return (
    <footer className="bg-[#0a192f] text-white pt-20 pb-10 border-t-4 border-[#e67e22]">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gradient-to-br from-[#e67e22] to-[#d35400] rounded-full flex items-center justify-center">
                <Construction className="text-white w-6 h-6" aria-hidden="true" />
              </div>
              <p className="text-2xl font-black uppercase">Tritón S.A.C</p>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Especialistas en ingeniería civil: movimiento de tierras masivo, demoliciones estructurales y gestión ambiental de residuos de construcción en Perú.
            </p>
          </div>

          <nav aria-label="Enlaces rápidos de navegación">
            <h4 className="text-lg font-bold mb-8 relative pb-4 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-1 after:bg-[#e67e22]">Menú Principal</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li><Link to="/" className="hover:text-[#e67e22] transition-colors flex items-center gap-2"><ChevronRight size={14} /> Inicio</Link></li>
              <li><Link to="/servicios" className="hover:text-[#e67e22] transition-colors flex items-center gap-2"><ChevronRight size={14} /> Servicios de Ingeniería</Link></li>
              <li><Link to="/especialidades" className="hover:text-[#e67e22] transition-colors flex items-center gap-2"><ChevronRight size={14} /> Obras Especializadas</Link></li>
              <li><Link to="/nosotros" className="hover:text-[#e67e22] transition-colors flex items-center gap-2"><ChevronRight size={14} /> Nuestra Trayectoria</Link></li>
              <li><Link to="/contacto" className="hover:text-[#e67e22] transition-colors flex items-center gap-2"><ChevronRight size={14} /> Contacto y Cotización</Link></li>
            </ul>
          </nav>

          <section aria-label="Nuestros servicios principales">
            <h4 className="text-lg font-bold mb-8 relative pb-4 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-1 after:bg-[#e67e22]">Servicios Clave</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li>Excavaciones para Edificios</li>
              <li>Demolición de Puentes</li>
              <li>Alquiler de Volquetes</li>
              <li>Nivelación de Terrenos Agrícolas</li>
              <li>Mantenimiento de Vías</li>
            </ul>
          </section>

          <address className="not-italic" aria-label="Ubicación y contacto">
            <h4 className="text-lg font-bold mb-8 relative pb-4 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-10 after:h-1 after:bg-[#e67e22]">Ubicación Lima</h4>
            <ul className="space-y-4 text-slate-400 text-sm">
              <li className="flex items-start gap-3"><MapPin size={18} className="text-[#e67e22] shrink-0" aria-hidden="true" /> <span>Av. Alameda Los Cedros Nº 185 - Of. 401, Chorrillos, Lima - Perú</span></li>
              <li className="flex items-center gap-3"><Phone size={18} className="text-[#e67e22] shrink-0" aria-hidden="true" /> <span>(01) 255-5650 / 989 123 055</span></li>
              <li className="flex items-center gap-3"><Mail size={18} className="text-[#e67e22] shrink-0" aria-hidden="true" /> <span>informes@triton.com.pe</span></li>
            </ul>
          </address>
        </div>
        <div className="pt-8 border-t border-slate-800 text-center text-slate-500 text-xs md:text-sm">
          <p>&copy; {new Date().getFullYear()} Corporación Internacional Tritón S.A.C. Ingeniería con Seguridad.</p>
        </div>
      </div>
    </footer>
  );
};

const SectionTitle = ({ title, subtitle, light = false, id }: { title: string, subtitle?: string, light?: boolean, id?: string }) => (
  <div className="text-center mb-16 px-4">
    <h2 id={id} className={`text-3xl md:text-4xl lg:text-5xl font-extrabold mb-6 relative inline-block pb-4 after:content-[''] after:absolute after:bottom-0 after:left-1/2 after:-translate-x-1/2 after:w-20 after:h-1 after:bg-[#e67e22] ${light ? 'text-white' : 'text-[#1a365d]'}`}>
      {title}
    </h2>
    {subtitle && <p className={`max-w-2xl mx-auto mt-4 text-lg leading-relaxed ${light ? 'text-slate-300' : 'text-slate-600'}`}>{subtitle}</p>}
  </div>
);

// --- Pages ---

const HomePage = () => {
  const location = useLocation();
  return (
    <main>
      <PageSEO 
        title="Inicio | Expertos en Movimiento de Tierras y Demoliciones" 
        description="Bienvenidos a Tritón S.A.C. Especialistas en excavaciones masivas, demolición controlada y preparación de suelos en Lima y todo el Perú." 
        path={location.pathname}
      />
      <StructuredData path={location.pathname} />
      <FAQSchema />
      
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center pt-20 overflow-hidden" aria-labelledby="hero-heading">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center animate-pulse-slow" role="img" aria-label="Maquinaria pesada trabajando en excavación masiva de terreno">
          <div className="absolute inset-0 bg-[#0a192f]/80"></div>
        </div>
        <div className="container relative mx-auto px-4 text-center text-white z-10 animate-fade-in-up">
          <h1 id="hero-heading" className="text-4xl md:text-6xl lg:text-7xl font-black mb-6 leading-tight">
            INGENIERÍA Y MOVIMIENTO <br />
            <span className="text-[#e67e22]">DE TIERRAS TRITÓN</span>
          </h1>
          <p className="max-w-3xl mx-auto text-lg md:text-xl text-slate-300 mb-10 leading-relaxed font-light">
            Soluciones avanzadas en demolición, eliminación de desmonte y nivelación de terrenos para proyectos de minería, industria y edificaciones urbanas.
          </p>
          <div className="flex flex-col sm:flex-row gap-5 justify-center">
            <Link to="/servicios" className="bg-[#e67e22] text-white px-10 py-4 rounded-full font-bold text-sm uppercase tracking-widest hover:bg-[#d35400] transition-colors flex items-center justify-center gap-2 group shadow-lg">
              <HardHat className="group-hover:rotate-12 transition-transform" aria-hidden="true" /> Servicios de Ingeniería
            </Link>
            <Link to="/contacto" className="bg-transparent border-2 border-white/40 text-white px-10 py-4 rounded-full font-bold text-sm uppercase tracking-widest hover:bg-white/10 hover:border-white transition-all flex items-center justify-center gap-2">
              <Phone size={18} aria-hidden="true" /> Presupuesto Gratis
            </Link>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-24 bg-slate-50" aria-labelledby="servicios-principales">
        <div className="container mx-auto px-4">
          <SectionTitle 
            id="servicios-principales"
            title="Nuestros Servicios de Construcción" 
            subtitle="Garantizamos precisión en excavaciones y seguridad total en demoliciones estructurales." 
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            {[
              { 
                title: "MOVIMIENTO DE TIERRAS", 
                desc: "Realizamos excavaciones masivas, nivelación y compactación de terrenos con tecnología láser en todo el Perú.",
                img: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80",
                alt: "Excavadora Caterpillar en obra de movimiento de tierras"
              },
              { 
                title: "DEMOLICIÓN CONTROLADA", 
                desc: "Desmantelamiento seguro de edificaciones industriales y residenciales con mínimo impacto ambiental.",
                img: "https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?auto=format&fit=crop&w=800&q=80",
                alt: "Demolición mecánica de estructuras de concreto"
              },
              { 
                title: "GESTIÓN DE DESMONTE", 
                desc: "Eliminación eficiente de residuos sólidos de construcción con disposición final en rellenos autorizados.",
                img: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?auto=format&fit=crop&w=800&q=80",
                alt: "Carguío de desmonte en volquete para eliminación"
              }
            ].map((s, idx) => (
              <article key={idx} className="bg-white rounded-2xl overflow-hidden shadow-xl group hover:-translate-y-3 transition-all duration-500 border border-slate-100">
                <div className="h-60 overflow-hidden relative">
                  <img src={s.img} alt={s.alt} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy" />
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-extrabold text-[#1a365d] mb-4 uppercase">{s.title}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed mb-6">{s.desc}</p>
                  <Link to="/servicios" className="text-[#e67e22] font-bold text-sm uppercase tracking-wider flex items-center gap-2 group-hover:gap-4 transition-all" aria-label={`Leer más sobre ${s.title}`}>
                    Ver Detalles <ArrowRight size={16} />
                  </Link>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section for SEO Rich Snippets */}
      <section className="py-24 bg-white" aria-labelledby="faq-title">
        <div className="container mx-auto px-4 max-w-4xl">
          <SectionTitle id="faq-title" title="Preguntas Frecuentes" subtitle="Resolvemos sus dudas sobre nuestros servicios de ingeniería." />
          <div className="space-y-6">
            {[
              { q: "¿En qué zonas del Perú brindan servicios?", a: "Contamos con operatividad logística para atender proyectos en Lima y todas las provincias del Perú, incluyendo zonas mineras de difícil acceso." },
              { q: "¿Qué maquinaria utilizan para las demoliciones?", a: "Utilizamos excavadoras equipadas con martillos hidráulicos, cizallas y pulverizadores de última generación para asegurar una demolición limpia y controlada." },
              { q: "¿Cuentan con certificaciones ambientales?", a: "Sí, todos nuestros procesos de eliminación de desmonte cumplen con las normativas ambientales vigentes y entregamos certificados de disposición final en botaderos autorizados." }
            ].map((item, i) => (
              <div key={i} className="bg-slate-50 p-6 rounded-2xl border-l-4 border-[#e67e22]">
                <h3 className="text-lg font-bold text-[#1a365d] mb-2 flex items-center gap-2">
                  <HelpCircle className="text-[#e67e22] w-5 h-5 shrink-0" aria-hidden="true" /> {item.q}
                </h3>
                <p className="text-slate-600 text-sm">{item.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

const ServicesPage = () => {
  const location = useLocation();
  const services = [
    { 
      id: "movimiento-tierras-especializado",
      title: "MOVIMIENTO DE TIERRAS", 
      icon: Tractor,
      subtitle: "Ingeniería de Suelos y Excavación",
      desc: "Servicios integrales de corte, relleno y compactación masiva. Preparación de cimientos para naves industriales y urbanizaciones.",
      bullets: ["Excavaciones masivas", "Relleno estructural", "Compactación dinámica", "Perfilado de taludes", "Control de polvo", "Transporte de maquinaria"],
      img: "https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80"
    },
    { 
      id: "demolicion-estructural-peru",
      title: "DEMOLICIÓN CONTROLADA", 
      icon: Hammer,
      subtitle: "Desmantelamiento y Derribo Seguro",
      desc: "Demolición de estructuras de concreto armado, acero y mampostería. Especialistas en derribos en entornos urbanos densos.",
      bullets: ["Demolición de edificios", "Corte de asfalto", "Desmontaje industrial", "Gestión de escombros", "Seguridad perimetral", "Plan de contingencia"],
      img: "https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?auto=format&fit=crop&w=800&q=80"
    }
  ];

  return (
    <main className="pt-24">
      <PageSEO 
        title="Servicios de Movimiento de Tierras y Demolición" 
        description="Explora nuestras soluciones en ingeniería vial, excavaciones y demoliciones. Maquinaria pesada propia y personal calificado." 
        path={location.pathname}
      />
      <StructuredData path={location.pathname} />
      <div className="bg-[#0a192f] py-20 text-white text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Servicios de <span className="text-[#e67e22]">Ingeniería</span></h1>
        <p className="max-w-3xl mx-auto text-slate-300 px-4">Tecnología aplicada al movimiento de tierras para optimizar costos y tiempos.</p>
      </div>
      
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          {services.map((s, i) => (
            <article key={i} id={s.id} className="mb-24 last:mb-0 bg-white rounded-3xl overflow-hidden shadow-2xl animate-fade-in border border-slate-100">
              <div className="bg-[#1a365d] p-8 md:p-12 text-white flex flex-col md:flex-row items-center gap-8">
                <s.icon className="w-16 h-16 text-[#e67e22] shrink-0" aria-hidden="true" />
                <h2 className="text-2xl md:text-4xl font-black uppercase tracking-tight">{s.title}</h2>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2">
                <div className="p-8 md:p-12 space-y-8">
                  <h3 className="text-2xl font-bold text-[#1a365d]">{s.subtitle}</h3>
                  <p className="text-slate-600 leading-relaxed text-lg">{s.desc}</p>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {s.bullets.map((b, bi) => (
                      <li key={bi} className="flex items-center gap-3 text-slate-700 font-medium">
                        <ChevronRight className="text-[#e67e22] w-4 h-4" aria-hidden="true" />
                        {b}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="relative min-h-[400px]">
                  <img src={s.img} alt={`Servicio especializado de ${s.title}`} className="absolute inset-0 w-full h-full object-cover" loading="lazy" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
};

const SpecialtiesPage = () => {
  const location = useLocation();
  const specs = [
    { title: "Infraestructura Vial y Caminos", icon: Layout, img: "https://images.unsplash.com/photo-1541746972996-4e0b0f43e02a?auto=format&fit=crop&w=800&q=80", desc: "Apertura de trochas, mantenimiento de vías mineras y construcción de terraplenes." },
    { title: "Nivelación para Parques Solares", icon: Sun, img: "https://images.unsplash.com/photo-1466611653911-95081537e5b7?auto=format&fit=crop&w=800&q=80", desc: "Adecuación milimétrica de terrenos para la instalación de energías renovables." }
  ];

  return (
    <main className="pt-24">
      <PageSEO 
        title="Obras Especiales y Movimiento de Tierras" 
        description="Especialidades en plataformas logísticas, canchas deportivas y obras viales. Precisión técnica en cada m3 de tierra." 
        path={location.pathname}
      />
      <StructuredData path={location.pathname} />
      <div className="bg-[#0a192f] py-20 text-white text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Nuestras <span className="text-[#e67e22]">Especialidades</span></h1>
        <p className="max-w-3xl mx-auto text-slate-300 px-4">Soluciones personalizadas para los desafíos más complejos de la construcción.</p>
      </div>

      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="space-y-32">
            {specs.map((sp, i) => (
              <article key={i} className={`flex flex-col lg:flex-row items-center gap-16 ${i % 2 !== 0 ? 'lg:flex-row-reverse' : ''}`}>
                <div className="lg:w-1/2 space-y-8 animate-fade-in">
                  <sp.icon className="w-16 h-16 text-[#e67e22]" aria-hidden="true" />
                  <h2 className="text-3xl md:text-4xl font-extrabold text-[#1a365d] uppercase tracking-tight">{sp.title}</h2>
                  <p className="text-lg text-slate-600 leading-relaxed">{sp.desc}</p>
                </div>
                <div className="lg:w-1/2 w-full h-[400px] md:h-[500px] rounded-3xl overflow-hidden shadow-2xl relative">
                  <img src={sp.img} alt={`Proyecto ejecutado de ${sp.title}`} className="w-full h-full object-cover" loading="lazy" />
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>
    </main>
  );
};

const AboutPage = () => {
  const location = useLocation();
  return (
    <main className="pt-24">
      <PageSEO 
        title="Quiénes Somos | Historia y Equipo Tritón" 
        description="Conoce la trayectoria de Tritón S.A.C. Especialistas en movimiento de tierras en Perú desde hace más de 15 años." 
        path={location.pathname}
      />
      <StructuredData path={location.pathname} />
      <div className="bg-[#0a192f] py-20 text-white text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Nuestra <span className="text-[#e67e22]">Trayectoria</span></h1>
        <p className="max-w-3xl mx-auto text-slate-300 px-4">Consolidando el futuro de la infraestructura peruana con ingeniería de calidad.</p>
      </div>

      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-10 animate-fade-in">
              <section className="space-y-4">
                <h2 className="text-3xl font-black text-[#1a365d] uppercase">Propósito Corporativo</h2>
                <p className="text-lg text-slate-600 leading-relaxed border-l-4 border-[#e67e22] pl-6 italic">
                  "Facilitar el desarrollo de proyectos de construcción a través de una gestión eficiente del terreno, priorizando siempre la seguridad de nuestro equipo y el respeto al entorno."
                </p>
              </section>
              <section className="space-y-4">
                <h2 className="text-3xl font-black text-[#1a365d] uppercase">Visión 2030</h2>
                <p className="text-lg text-slate-600 leading-relaxed border-l-4 border-[#1a365d] pl-6">
                  Ser referentes regionales en servicios de ingeniería civil y movimiento de tierras, reconocidos por nuestra capacidad técnica y ética empresarial.
                </p>
              </section>
            </div>
            <div className="rounded-3xl overflow-hidden shadow-2xl border-8 border-slate-50">
              <img src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=800&q=80" alt="Maquinaria de Tritón S.A.C. operando en proyecto minero" className="w-full h-auto" loading="lazy" />
            </div>
          </div>
        </div>
      </section>
    </main>
  );
};

const ContactPage = () => {
  const location = useLocation();
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Solicitud recibida. Un especialista de Tritón se contactará con usted en breve.");
  };

  return (
    <main className="pt-24">
      <PageSEO 
        title="Contacto y Presupuestos de Obra" 
        description="Contáctanos para presupuestos de movimiento de tierras y demoliciones. Atención inmediata para empresas constructoras y mineras." 
        path={location.pathname}
      />
      <StructuredData path={location.pathname} />
      <div className="bg-[#0a192f] py-20 text-white text-center">
        <h1 className="text-4xl md:text-6xl font-black mb-6">Cotice su <span className="text-[#e67e22]">Proyecto</span></h1>
        <p className="max-w-3xl mx-auto text-slate-300 px-4">Asesoría técnica inmediata y presupuestos detallados para su próxima obra.</p>
      </div>

      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <address className="lg:col-span-1 space-y-8 not-italic animate-fade-in">
              <div className="bg-white p-10 rounded-3xl shadow-xl border-b-4 border-[#e67e22]">
                <h2 className="text-2xl font-black text-[#1a365d] mb-8 uppercase">Canales Directos</h2>
                <div className="space-y-8">
                  <div className="flex gap-5">
                    <MapPin className="text-[#e67e22] shrink-0" size={24} aria-hidden="true" />
                    <div>
                      <h3 className="font-bold text-[#1a365d]">Oficina Principal</h3>
                      <p className="text-slate-600 text-sm">Av. Alameda Los Cedros Nº 185 - Of. 401, Chorrillos, Lima</p>
                    </div>
                  </div>
                  <div className="flex gap-5">
                    <Phone className="text-[#e67e22] shrink-0" size={24} aria-hidden="true" />
                    <div>
                      <h3 className="font-bold text-[#1a365d]">Contacto Comercial</h3>
                      <p className="text-slate-600 text-sm">989 123 055 / (01) 255-5650</p>
                    </div>
                  </div>
                </div>
              </div>
            </address>

            <div className="lg:col-span-2">
              <article className="bg-white p-10 md:p-12 rounded-3xl shadow-2xl border-t-4 border-[#1a365d]">
                <h2 className="text-3xl font-black text-[#1a365d] mb-10 uppercase">Formulario de Cotización</h2>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="full-name" className="text-sm font-bold text-slate-700 uppercase">Nombre o Empresa *</label>
                      <input id="full-name" name="name" type="text" required placeholder="Ej. Constructora ABC" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:ring-2 focus:ring-[#e67e22] outline-none transition-all" />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="user-email" className="text-sm font-bold text-slate-700 uppercase">Correo de Contacto *</label>
                      <input id="user-email" name="email" type="email" required placeholder="contacto@empresa.com" className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:ring-2 focus:ring-[#e67e22] outline-none transition-all" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label htmlFor="proj-details" className="text-sm font-bold text-slate-700 uppercase">Especificaciones del Trabajo *</label>
                    <textarea id="proj-details" name="message" required rows={6} placeholder="Detalle el volumen de tierra (m3), área de demolición (m2) y ubicación del proyecto." className="w-full bg-slate-50 border border-slate-200 rounded-xl px-5 py-4 focus:ring-2 focus:ring-[#e67e22] outline-none transition-all resize-none"></textarea>
                  </div>
                  <button type="submit" className="w-full md:w-auto bg-[#e67e22] text-white px-12 py-5 rounded-full font-black uppercase tracking-widest hover:bg-[#d35400] transition-colors shadow-xl">Solicitar Análisis Técnico</button>
                </form>
              </article>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="h-[500px] w-full bg-slate-200 relative overflow-hidden" aria-label="Mapa de ubicación de la oficina">
        <iframe 
          title="Ubicación exacta de Corporación Internacional Tritón S.A.C."
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3901.965939467485!2d-76.998925!3d-12.046450000000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x9105c5f619ee3ec7%3A0x14206cb9cc452b4a!2sAv.%20Alameda%20Los%20Cedros%20185%2C%20Chorrillos%2015067!5e0!3m2!1ses!2spe!4v1647461234567!5m2!1ses!2spe" 
          className="w-full h-full grayscale hover:grayscale-0 transition-all duration-1000 border-0"
          allowFullScreen 
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade">
        </iframe>
        <div className="absolute top-8 left-8 bg-[#0a192f] text-white p-6 rounded-2xl shadow-2xl pointer-events-none hidden md:block border-2 border-[#e67e22] max-w-xs animate-fade-in">
          <div className="flex items-center gap-2 mb-2 text-[#e67e22]">
            <MapPin size={20} />
            <h4 className="font-bold text-lg">Nuestra Sede</h4>
          </div>
          <p className="text-sm text-slate-300">Av. Alameda Los Cedros 185, Of. 401. Chorrillos, Lima - Perú.</p>
          <div className="mt-4 pt-4 border-t border-slate-700 flex items-center justify-between">
            <span className="text-xs text-slate-400 uppercase tracking-widest font-bold">Abierto</span>
            <span className="text-xs text-slate-300">Lun - Vie: 8am - 6pm</span>
          </div>
        </div>
      </section>
    </main>
  );
};

// --- App Root ---

const ScrollToTopOnRouteChange = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const App = () => {
  return (
    <Router>
      <ScrollToTopOnRouteChange />
      <div className="flex flex-col min-h-screen">
        <Header />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/servicios" element={<ServicesPage />} />
          <Route path="/especialidades" element={<SpecialtiesPage />} />
          <Route path="/nosotros" element={<AboutPage />} />
          <Route path="/contacto" element={<ContactPage />} />
        </Routes>
        <Footer />
        <BackToTop />
      </div>
    </Router>
  );
};

export default App;
